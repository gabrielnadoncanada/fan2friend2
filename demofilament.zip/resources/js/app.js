import './Calendar'
import './components';


// document.addEventListener('livewire:initialized', () => {
//     window.addEventListener('beforeunload', () => {
//         Livewire.dispatch('removeFromWaitingRoom')
//     });
// });

