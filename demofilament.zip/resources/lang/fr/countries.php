<?php

return [
    'CA' => 'Canada',
];
