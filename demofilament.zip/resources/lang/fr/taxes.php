<?php

return [
    'GST' => 'TPS',
    'PST' => 'TVQ',
    'HST' => 'TVH',
    'QST' => 'TVQ',
];
