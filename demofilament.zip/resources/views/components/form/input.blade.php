<input type="{{ $type }}" value="{{ $value }}" {{ $controlAttributes() }}>
