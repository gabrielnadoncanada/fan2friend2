<div {{ $attributes->merge(['class' => $theme()]) }}>
    {{ $slot }}
</div>
