<ul {{ $attributes->merge(['class' => $theme()]) }}>
    {{ $slot }}
</ul>

