<?php

namespace App\Filament\Resources\CelebrityResource\Pages;

use App\Filament\Resources\CelebrityResource;
use Filament\Resources\Pages\CreateRecord;

class CreateCelebrity extends CreateRecord
{
    protected static string $resource = CelebrityResource::class;
}
